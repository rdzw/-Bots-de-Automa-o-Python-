#!/bin/bash

zip -r "Botyoutube.zip" * -x "Botyoutube.zip"