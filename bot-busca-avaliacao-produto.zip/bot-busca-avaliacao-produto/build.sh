#!/bin/bash

zip -r "bot-busca-avaliacao-produto.zip" * -x "bot-busca-avaliacao-produto.zip"